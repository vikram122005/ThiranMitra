/* ============================================================
   ROZGARSETU — api.js
   Universal frontend API client for the Flask backend.
   All fetch calls go through here — auth headers auto-attached.
   ============================================================ */

'use strict';

const API_BASE = 'http://localhost:5000/api';

/* ── Token helpers ────────────────────────────────────────── */
const Token = {
    get() { return localStorage.getItem('wm_token'); },
    set(t) { localStorage.setItem('wm_token', t); },
    remove() { localStorage.removeItem('wm_token'); localStorage.removeItem('wm_user'); },
    headers() {
        const h = { 'Content-Type': 'application/json' };
        const t = Token.get();
        if (t) h['Authorization'] = `Bearer ${t}`;
        return h;
    }
};

/* ── Core fetch wrapper ───────────────────────────────────── */
async function apiFetch(path, options = {}) {
    const url = `${API_BASE}${path}`;
    const res = await fetch(url, {
        headers: Token.headers(),
        ...options,
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
    return json;
}

/* ═══════════════════════════════════════════════════════════
   AUTH API
═════════════════════════════════════════════════════════════ */
const AuthAPI = {
    async register(data) {
        const resp = await apiFetch('/auth/register', {
            method: 'POST', body: JSON.stringify(data)
        });
        Token.set(resp.token);
        localStorage.setItem('wm_user', JSON.stringify(resp.user));
        return resp;
    },

    async login(email, password) {
        const resp = await apiFetch('/auth/login', {
            method: 'POST', body: JSON.stringify({ email, password })
        });
        Token.set(resp.token);
        localStorage.setItem('wm_user', JSON.stringify(resp.user));
        return resp;
    },

    async me() {
        return apiFetch('/auth/me');
    },

    async logout() {
        await apiFetch('/auth/logout', { method: 'POST' }).catch(() => { });
        Token.remove();
        window.location.href = 'index.html';
    },

    isLoggedIn() { return !!Token.get(); },

    currentUser() {
        try { return JSON.parse(localStorage.getItem('wm_user') || 'null'); }
        catch { return null; }
    }
};

/* ═══════════════════════════════════════════════════════════
   JOBS API
═════════════════════════════════════════════════════════════ */
const JobsAPI = {
    list(params = {}) {
        const qs = new URLSearchParams(params).toString();
        return apiFetch(`/jobs${qs ? '?' + qs : ''}`);
    },
    detail(id) { return apiFetch(`/jobs/${id}`); },
    save(id) { return apiFetch(`/jobs/${id}/save`, { method: 'POST' }); },
    unsave(id) { return apiFetch(`/jobs/${id}/save`, { method: 'DELETE' }); },
    saved() { return apiFetch('/jobs/saved'); },
    apply(id, note = '') {
        return apiFetch(`/jobs/${id}/apply`, {
            method: 'POST', body: JSON.stringify({ cover_note: note })
        });
    },
    applied() { return apiFetch('/jobs/applied'); },
    recommended() { return apiFetch('/jobs/recommended'); },
};

/* ═══════════════════════════════════════════════════════════
   PROFILE API
═════════════════════════════════════════════════════════════ */
const ProfileAPI = {
    get() { return apiFetch('/profile'); },
    update(data) { return apiFetch('/profile', { method: 'PUT', body: JSON.stringify(data) }); },
    stats() { return apiFetch('/profile/stats'); },

    // Education
    getEducation() { return apiFetch('/profile/education'); },
    addEducation(data) { return apiFetch('/profile/education', { method: 'POST', body: JSON.stringify(data) }); },
    delEducation(id) { return apiFetch(`/profile/education/${id}`, { method: 'DELETE' }); },

    // Experience
    getExperience() { return apiFetch('/profile/experience'); },
    addExperience(data) { return apiFetch('/profile/experience', { method: 'POST', body: JSON.stringify(data) }); },
    delExperience(id) { return apiFetch(`/profile/experience/${id}`, { method: 'DELETE' }); },

    // Skills
    getSkills() { return apiFetch('/profile/skills'); },
    addSkills(skills, level = 'Intermediate') {
        return apiFetch('/profile/skills', {
            method: 'POST', body: JSON.stringify({ skills, level })
        });
    },
    delSkill(id) { return apiFetch(`/profile/skills/${id}`, { method: 'DELETE' }); },

    // Certificates
    getCerts() { return apiFetch('/profile/certificates'); },
    addCert(data) { return apiFetch('/profile/certificates', { method: 'POST', body: JSON.stringify(data) }); },
    delCert(id) { return apiFetch(`/profile/certificates/${id}`, { method: 'DELETE' }); },

    // Preferences
    getPrefs() { return apiFetch('/profile/preferences'); },
    updatePrefs(data) { return apiFetch('/profile/preferences', { method: 'PUT', body: JSON.stringify(data) }); },

    // Resumes
    getResumes() { return apiFetch('/profile/resumes'); },
    addResume(data) { return apiFetch('/profile/resumes', { method: 'POST', body: JSON.stringify(data) }); },
};

/* ═══════════════════════════════════════════════════════════
   DASHBOARD API
═════════════════════════════════════════════════════════════ */
const DashboardAPI = {
    get() { return apiFetch('/dashboard'); }
};

/* ═══════════════════════════════════════════════════════════
   INTERVIEW API
═════════════════════════════════════════════════════════════ */
const InterviewAPI = {
    getScores() { return apiFetch('/interview/scores'); },
    saveScore(data) {
        return apiFetch('/interview/scores', {
            method: 'POST', body: JSON.stringify(data)
        });
    }
};

/* ═══════════════════════════════════════════════════════════
   PLACEMENT API
═════════════════════════════════════════════════════════════ */
const PlacementAPI = {
    getScores() { return apiFetch('/placement/scores'); },
    saveScore(data) {
        // data should have: test_type, score_pct, correct, wrong, skipped
        return apiFetch('/placement/scores', {
            method: 'POST', body: JSON.stringify(data)
        });
    }
};

/* ═══════════════════════════════════════════════════════════
   SCHEMES API
═════════════════════════════════════════════════════════════ */
const SchemesAPI = {
    list(params = {}) {
        const qs = new URLSearchParams(params).toString();
        return apiFetch(`/schemes${qs ? '?' + qs : ''}`);
    },
    detail(id) { return apiFetch(`/schemes/${id}`); }
};

/* ═══════════════════════════════════════════════════════════
   SUPPORT API
═════════════════════════════════════════════════════════════ */
const SupportAPI = {
    submit(data) {
        return apiFetch('/support', { method: 'POST', body: JSON.stringify(data) });
    }
};

/* ── UI Helpers that use the API ──────────────────────────── */

/**
 * Initialise navbar state based on login status.
 * Call this in DOMContentLoaded on any page.
 */
function initAuthUI() {
    const user = AuthAPI.currentUser();
    const loginBtn = document.querySelector('a[href="login.html"]');
    const regBtn = document.querySelector('a[href="register.html"]');
    const profBtn = document.querySelector('a[href="profile.html"]');
    const logoutBtn = document.querySelector('[onclick*="logout"]');

    if (AuthAPI.isLoggedIn() && user) {
        // Show profile + logout, hide login/register
        if (loginBtn) loginBtn.style.display = 'none';
        if (regBtn) regBtn.style.display = 'none';
        if (profBtn) profBtn.style.display = '';
        if (logoutBtn) logoutBtn.style.display = '';
    }
}

/**
 * Guard — redirect to login if not authenticated.
 * Use on dashboard, profile, resume etc.
 */
function requireAuth(redirectTo = 'login.html') {
    if (!AuthAPI.isLoggedIn()) {
        if (typeof showToast === 'function') {
            showToast('Please login to access this page.', 'warning');
        }
        setTimeout(() => window.location.href = redirectTo, 1000);
        return false;
    }
    return true;
}

/**
 * Show a server error gracefully.
 */
function handleApiError(err, fallbackMsg = 'Something went wrong. Please try again.') {
    const msg = err?.message || fallbackMsg;
    if (typeof showToast === 'function') showToast(`❌ ${msg}`, 'error', 4000);
    console.error('[API Error]', err);
}

/* ── Backwards compatibility: keep old localStorage helpers working ── */
function getCurrentUser() {
    return AuthAPI.currentUser() || { name: 'Guest', email: '' };
}
function isLoggedIn() { return AuthAPI.isLoggedIn(); }
function logout() { AuthAPI.logout(); }
