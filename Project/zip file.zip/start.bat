@echo off
echo ================================================
echo   WorkMitra - Starting Full Stack Application
echo ================================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found! Please install Python 3.x
    pause
    exit /b 1
)

:: Check if Flask is installed
python -c "import flask" >nul 2>&1
if errorlevel 1 (
    echo [INSTALLING] Installing backend dependencies...
    pip install flask flask-cors PyJWT bcrypt
)

echo.
echo [DB] Initialising database...
echo [SERVER] Starting Flask backend on http://localhost:5000
echo [OPEN] Opening WorkMitra in your browser...
echo.
echo Press Ctrl+C to stop the server.
echo.

:: Open browser after 2-second delay (background)
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:5000/index.html"

:: Start Flask server (foreground)
cd /d "%~dp0backend"
python app.py
