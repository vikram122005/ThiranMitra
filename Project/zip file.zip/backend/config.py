"""
WorkMitra Backend Configuration
"""
import os

# ── Security ──────────────────────────────────────
SECRET_KEY   = os.environ.get('RS_SECRET', 'workmitra-super-secret-2026-change-in-prod')
JWT_EXPIRY_H = 24   # JWT token valid for 24 hours

# ── Database ────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, 'workmitra.db')

# ── CORS ────────────────────────────────────────────
ALLOWED_ORIGINS = ['http://localhost:8080', 'http://127.0.0.1:8080',
                   'http://localhost:5500', 'http://127.0.0.1:5500',
                   'null']   # file:// opens as null origin

# ── App ─────────────────────────────────────────────
DEBUG = True
PORT  = 5000
HOST  = '0.0.0.0'
