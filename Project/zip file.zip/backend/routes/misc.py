"""
Interview + Placement + Schemes + Dashboard routes

GET  /api/interview/scores        — my past scores
POST /api/interview/scores        — save a score
GET  /api/placement/scores
POST /api/placement/scores
GET  /api/schemes                 — list schemes (filter by category)
GET  /api/schemes/<id>
GET  /api/dashboard               — aggregated career AI dashboard
POST /api/support                 — submit support ticket
"""
import json
from flask import Blueprint, request, jsonify, g
from database import get_db
from middleware import token_required

interview_bp  = Blueprint('interview',  __name__, url_prefix='/api/interview')
placement_bp  = Blueprint('placement',  __name__, url_prefix='/api/placement')
schemes_bp    = Blueprint('schemes',    __name__, url_prefix='/api/schemes')
dashboard_bp  = Blueprint('dashboard',  __name__, url_prefix='/api/dashboard')
support_bp    = Blueprint('support',    __name__, url_prefix='/api/support')


# ══════════════════════════════════════════════════════════════
#  INTERVIEW
# ══════════════════════════════════════════════════════════════
@interview_bp.route('/scores', methods=['GET'])
@token_required
def get_interview_scores():
    db   = get_db()
    rows = db.execute(
        "SELECT * FROM interview_scores WHERE user_id=? ORDER BY taken_at DESC LIMIT 10",
        (g.user_id,)).fetchall()
    db.close()
    result = []
    for r in rows:
        d = dict(r)
        try:
            d['feedback'] = json.loads(d['feedback'] or '[]')
        except Exception:
            d['feedback'] = []
        result.append(d)
    return jsonify({'scores': result})


@interview_bp.route('/scores', methods=['POST'])
@token_required
def save_interview_score():
    data    = request.get_json(force=True) or {}
    role    = data.get('role', '')
    readiness = data.get('readiness_pct', 0)
    confidence = data.get('confidence_pct', 0)
    clarity   = data.get('clarity_pct', 0)
    star      = data.get('star_pct', 0)
    grammar   = data.get('grammar_pct', 0)
    feedback  = json.dumps(data.get('feedback', []))

    db  = get_db()
    cur = db.execute("""
        INSERT INTO interview_scores
            (user_id, role, readiness_pct, confidence_pct, clarity_pct, star_pct, grammar_pct, feedback)
        VALUES (?,?,?,?,?,?,?,?)
    """, (g.user_id, role, readiness, confidence, clarity, star, grammar, feedback))
    db.commit()
    new = db.execute("SELECT * FROM interview_scores WHERE id=?",
                     (cur.lastrowid,)).fetchone()
    db.close()
    return jsonify({'score': dict(new)}), 201


# ══════════════════════════════════════════════════════════════
#  PLACEMENT
# ══════════════════════════════════════════════════════════════
@placement_bp.route('/scores', methods=['GET'])
@token_required
def get_placement_scores():
    db   = get_db()
    rows = db.execute(
        "SELECT * FROM placement_scores WHERE user_id=? ORDER BY taken_at DESC LIMIT 20",
        (g.user_id,)).fetchall()
    db.close()
    return jsonify({'scores': [dict(r) for r in rows]})


@placement_bp.route('/scores', methods=['POST'])
@token_required
def save_placement_score():
    data = request.get_json(force=True) or {}
    db   = get_db()
    cur  = db.execute("""
        INSERT INTO placement_scores (user_id, test_type, score_pct, correct, wrong, skipped)
        VALUES (?,?,?,?,?,?)
    """, (g.user_id, data.get('test_type', 'aptitude'),
          data.get('score_pct', 0), data.get('correct', 0),
          data.get('wrong', 0), data.get('skipped', 0)))
    db.commit()
    db.close()
    return jsonify({'id': cur.lastrowid}), 201


# ══════════════════════════════════════════════════════════════
#  SCHEMES
# ══════════════════════════════════════════════════════════════
@schemes_bp.route('', methods=['GET'])
def list_schemes():
    category  = request.args.get('category', '').strip()
    is_central = request.args.get('central', type=int)   # 1 or 0
    q          = request.args.get('q', '').strip()

    sql    = "SELECT * FROM schemes WHERE 1=1"
    params = []
    if category:
        sql += " AND category = ?"
        params.append(category)
    if is_central is not None:
        sql += " AND is_central = ?"
        params.append(is_central)
    if q:
        sql += " AND (name LIKE ? OR description LIKE ?)"
        params += [f'%{q}%', f'%{q}%']

    db   = get_db()
    rows = db.execute(sql + " ORDER BY id", params).fetchall()
    db.close()
    return jsonify({'schemes': [dict(r) for r in rows]})


@schemes_bp.route('/<int:scheme_id>', methods=['GET'])
def scheme_detail(scheme_id):
    db  = get_db()
    row = db.execute("SELECT * FROM schemes WHERE id=?", (scheme_id,)).fetchone()
    db.close()
    if not row:
        return jsonify({'error': 'Scheme not found'}), 404
    return jsonify({'scheme': dict(row)})


# ══════════════════════════════════════════════════════════════
#  DASHBOARD — AI Career Summary
# ══════════════════════════════════════════════════════════════
@dashboard_bp.route('', methods=['GET'])
@token_required
def dashboard():
    db = get_db()
    user     = db.execute("SELECT * FROM users WHERE id=?", (g.user_id,)).fetchone()
    skills   = [r['skill_name'] for r in db.execute(
        "SELECT skill_name FROM skills WHERE user_id=?", (g.user_id,)).fetchall()]
    saved    = db.execute("SELECT COUNT(*) FROM saved_jobs WHERE user_id=?",
                          (g.user_id,)).fetchone()[0]
    applied  = db.execute("SELECT COUNT(*) FROM applications WHERE user_id=?",
                          (g.user_id,)).fetchone()[0]
    last_iv  = db.execute(
        "SELECT * FROM interview_scores WHERE user_id=? ORDER BY taken_at DESC LIMIT 1",
        (g.user_id,)).fetchone()
    last_res = db.execute(
        "SELECT * FROM resumes WHERE user_id=? ORDER BY uploaded_at DESC LIMIT 1",
        (g.user_id,)).fetchone()
    last_pl  = db.execute(
        "SELECT * FROM placement_scores WHERE user_id=? ORDER BY taken_at DESC LIMIT 1",
        (g.user_id,)).fetchone()
    db.close()

    # Compute profile completeness
    completion = 20   # base for creating account
    if user['phone']:             completion += 10
    if user['city']:              completion += 10
    if skills:                    completion += 20
    if last_res:                  completion += 20
    if last_iv:                   completion += 10
    if applied > 0:               completion += 10

    # Career predictions (rule-based)
    predictions = []
    sl = [s.lower() for s in skills]
    if any(k in ' '.join(sl) for k in ['react','node','python','java','flutter','angular']):
        predictions.append({'role': 'Full Stack Developer',  'match': 87, 'icon': '💻'})
    if any(k in ' '.join(sl) for k in ['sql','python','excel','power bi','data','analytics']):
        predictions.append({'role': 'Data Analyst',         'match': 74, 'icon': '📊'})
    if any(k in ' '.join(sl) for k in ['marketing','seo','content','canva','social']):
        predictions.append({'role': 'Digital Marketer',     'match': 71, 'icon': '📣'})
    if not predictions:
        predictions = [
            {'role': 'Software Developer', 'match': 60, 'icon': '💻'},
            {'role': 'Data Entry Operator', 'match': 55, 'icon': '📋'},
        ]

    # Skill gap (top 5 in-demand skills user doesn't have)
    IN_DEMAND = ['Python', 'React.js', 'SQL', 'Machine Learning', 'AWS',
                 'Docker', 'Figma', 'TypeScript', 'Power BI', 'Git']
    skill_gap = [s for s in IN_DEMAND if s.lower() not in sl][:5]

    return jsonify({
        'user':             dict(user),
        'skills':           skills,
        'saved_jobs':       saved,
        'applied_jobs':     applied,
        'profile_completion': min(100, completion),
        'interview_score':  last_iv['readiness_pct'] if last_iv else None,
        'resume_ats':       last_res['ats_score']    if last_res else None,
        'placement_score':  last_pl['score_pct']     if last_pl else None,
        'career_predictions': predictions,
        'skill_gap':        skill_gap,
    })


# ══════════════════════════════════════════════════════════════
#  SUPPORT TICKETS
# ══════════════════════════════════════════════════════════════
@support_bp.route('', methods=['POST'])
def submit_ticket():
    data    = request.get_json(force=True) or {}
    message = (data.get('message') or '').strip()
    if not message:
        return jsonify({'error': 'Message is required'}), 400
    # Get user_id if logged in (optional)
    from middleware import optional_auth
    user_id = None
    auth    = request.headers.get('Authorization', '')
    if auth.startswith('Bearer '):
        import jwt
        from config import SECRET_KEY
        try:
            user_id = jwt.decode(auth.split()[1], SECRET_KEY,
                                 algorithms=['HS256'])['sub']
        except Exception:
            pass

    db  = get_db()
    cur = db.execute("""
        INSERT INTO support_tickets (user_id, name, email, subject, message)
        VALUES (?,?,?,?,?)
    """, (user_id, data.get('name'), data.get('email'),
          data.get('subject', 'General Inquiry'), message))
    db.commit()
    db.close()
    return jsonify({'message': 'Support ticket submitted. We\'ll respond within 24 hours.',
                    'ticket_id': cur.lastrowid}), 201
