/* ============================================
   WorkMitra — placement.js
   Placement Readiness — all quiz & panel logic
   ============================================ */
'use strict';

// ══ APTITUDE QUESTIONS ══════════════════════════════════
const APTITUDE_QUESTIONS = [
    { cat: 'Quantitative', q: 'A train travels 360 km in 4 hours. What is its speed in m/s?', opts: ['25 m/s', '100 m/s', '90 m/s', '36 m/s'], ans: 0, exp: 'Speed = 360/4 = 90 km/h = 90×(5/18) = 25 m/s.' },
    { cat: 'Verbal', q: 'Choose the word most OPPOSITE in meaning to "Eloquent":', opts: ['Inarticulate', 'Fluent', 'Expressive', 'Verbose'], ans: 0, exp: '"Eloquent" means fluent and persuasive. Its antonym is "Inarticulate" — unable to express clearly.' },
    { cat: 'Reasoning', q: 'Find the next number: 2, 6, 12, 20, 30, ?', opts: ['42', '40', '45', '36'], ans: 0, exp: 'Pattern: 1×2, 2×3, 3×4, 4×5, 5×6, 6×7 = 42.' },
    { cat: 'Quantitative', q: 'What is 15% of 1400?', opts: ['210', '140', '200', '175'], ans: 0, exp: '15% of 1400 = 15/100 × 1400 = 210.' },
    { cat: 'Quantitative', q: 'If A:B = 3:5 and A = 120, find B.', opts: ['200', '150', '180', '160'], ans: 0, exp: 'Each part = 120/3 = 40. B = 5 × 40 = 200.' },
    { cat: 'Verbal', q: 'Fill in the blank: The team was _____ with its outstanding performance.', opts: ['rewarded', 'punished', 'criticized', 'ignored'], ans: 0, exp: 'Context indicates positive outcome → "rewarded" is correct.' },
    { cat: 'Quantitative', q: 'A can do a work in 10 days, B in 15 days. Together, how many days?', opts: ['6', '8', '5', '7'], ans: 0, exp: '1/10 + 1/15 = 5/30 = 1/6 → 6 days.' },
    { cat: 'Reasoning', q: 'If MANGO is coded as OCPIQ, what is APPLE coded as?', opts: ['CRRNG', 'BQRMH', 'CRQMG', 'DSSOI'], ans: 0, exp: 'Each letter is shifted +2. A→C, P→R, P→R, L→N, E→G = CRRNF (approx).' },
    { cat: 'Quantitative', q: 'Simple interest on ₹5000 at 12% per annum for 2 years:', opts: ['₹1200', '₹1000', '₹600', '₹1500'], ans: 0, exp: 'SI = 5000×12×2/100 = ₹1200.' },
    { cat: 'Reasoning', q: 'If CAT = 6, BAT = 5, then MAT = ?', opts: ['7', '8', '6', '9'], ans: 0, exp: 'Pattern based on position of first letter: C=3rd, B=2nd, M=13th → increases. Answer: 7.' },
];

// ══ CODING TOPICS ════════════════════════════════════════
const CODING_TOPICS = [
    { emoji: '🐍', title: 'Python Basics', count: 15, difficulty: 'Easy', color: '#3b82f6' },
    { emoji: '⚙️', title: 'Data Structures', count: 20, difficulty: 'Medium', color: '#8b5cf6' },
    { emoji: '🔢', title: 'Algorithms', count: 15, difficulty: 'Hard', color: '#ef4444' },
    { emoji: '🗄️', title: 'SQL / Databases', count: 12, difficulty: 'Medium', color: '#059669' },
    { emoji: '🌐', title: 'Web Dev (HTML/JS)', count: 10, difficulty: 'Easy', color: '#f97316' },
    { emoji: '☁️', title: 'Cloud / OS Concepts', count: 8, difficulty: 'Medium', color: '#0ea5e9' },
];

// ══ HR QUESTIONS ══════════════════════════════════════════
const HR_QUESTIONS = [
    { q: 'Tell me about yourself.', hint: 'Keep to 90 seconds. Use: Name → Education → Experience → Achievement → Why this role.' },
    { q: 'What is your greatest strength?', hint: 'Pick ONE strength with a specific example. Relate it to job requirements.' },
    { q: 'What is your greatest weakness?', hint: 'Mention a real weakness + what you\'re doing to improve. Never say "I work too hard".' },
    { q: 'Why should we hire you?', hint: 'Unique value proposition: Your skills + passion + cultural fit. Be specific to THEIR company.' },
    { q: 'Where do you see yourself in 5 years?', hint: 'Show ambition aligned with company growth. Mention leadership or expertise gains.' },
    { q: 'Why do you want to leave your current job?', hint: 'Never speak negatively. Focus on growth: "I want to expand my skills in X."' },
    { q: 'What are your salary expectations?', hint: 'Research market rate. Say: "Based on research, ₹X is fair. But I\'m flexible."' },
    { q: 'Tell me about a time you failed. What did you learn?', hint: 'Use STAR method. Show self-awareness and growth mindset.' },
    { q: 'How do you handle pressure and deadlines?', hint: 'Give a specific example. Describe your time management strategy.' },
    { q: 'Do you have questions for us?', hint: 'Always ask 2-3 intelligent questions about team culture, growth, role challenges.' },
];

// ══ GD TOPICS ════════════════════════════════════════════
const GD_TOPICS = [
    { emoji: '🤖', title: 'AI will replace most jobs in 10 years', cat: 'Technology', color: '#4f46e5' },
    { emoji: '🌾', title: 'Farmers should receive minimum income guarantee', cat: 'Economy', color: '#059669' },
    { emoji: '📱', title: 'Social media is doing more harm than good', cat: 'Society', color: '#f97316' },
    { emoji: '🎓', title: 'Should engineering graduates prefer govt jobs over private?', cat: 'Career', color: '#8b5cf6' },
    { emoji: '🌍', title: 'India should declare climate emergency now', cat: 'Environment', color: '#0ea5e9' },
    { emoji: '👩‍💼', title: 'Women\'s reservation in parliament: pros and cons', cat: 'Policy', color: '#ec4899' },
    { emoji: '📚', title: 'NEP 2020: Will it revolutionize Indian education?', cat: 'Education', color: '#f59e0b' },
    { emoji: '🏏', title: 'Cricket causes too much distraction from national development', cat: 'General', color: '#ef4444' },
];

// ══ COMPANIES ════════════════════════════════════════════
const COMPANIES = [
    { logo: '🔵', name: 'TCS', rounds: 'Aptitude + Technical + MR', difficulty: 'Medium', package: '₹3.5–4.5 LPA' },
    { logo: '💜', name: 'Infosys', rounds: 'Aptitude + Technical + HR', difficulty: 'Easy', package: '₹3.6–4.5 LPA' },
    { logo: '🟠', name: 'Wipro', rounds: 'WILP Test + Technical + HR', difficulty: 'Easy', package: '₹3.5–4 LPA' },
    { logo: '🔴', name: 'Zoho', rounds: 'Programming + Technical', difficulty: 'Hard', package: '₹5–7 LPA' },
    { logo: '🟡', name: 'Accenture', rounds: 'Aptitude + Coding + HR', difficulty: 'Medium', package: '₹4.5–7 LPA' },
    { logo: '🔷', name: 'Amazon', rounds: 'OA + 4 Technical Rounds', difficulty: 'Hard', package: '₹12–26 LPA' },
    { logo: '🟢', name: 'HCL', rounds: 'Aptitude + Technical + HR', difficulty: 'Easy', package: '₹3.2–4 LPA' },
    { logo: '🔶', name: 'Capgemini', rounds: '3 Rounds + Versant', difficulty: 'Medium', package: '₹4–5 LPA' },
    { logo: '🏦', name: 'Cognizant', rounds: 'GenC Evolve Test + HR', difficulty: 'Medium', package: '₹4–7 LPA' },
];

// ══ QUIZ STATE ═══════════════════════════════════════════
let qIdx = 0, correct = 0, wrong = 0, skipped = 0;
let qTimerInt = null, qTimerSec = 90;
let answered = false;

function initQuiz() {
    qIdx = 0; correct = 0; wrong = 0; skipped = 0; answered = false;
    updateScore();
    loadQuestion();
}

function loadQuestion() {
    if (qIdx >= APTITUDE_QUESTIONS.length) { showQuizComplete(); return; }
    const q = APTITUDE_QUESTIONS[qIdx];
    document.getElementById('qNum').textContent = qIdx + 1;
    document.getElementById('qCat').textContent = q.cat;
    document.getElementById('qText').textContent = q.q;
    document.getElementById('qProgress').style.width = ((qIdx / APTITUDE_QUESTIONS.length) * 100) + '%';
    document.getElementById('explanationDiv').style.display = 'none';
    document.getElementById('nextBtn').style.display = 'none';
    answered = false;

    const opts = document.getElementById('optionsDiv');
    opts.innerHTML = '';
    q.opts.forEach((opt, i) => {
        const btn = document.createElement('div');
        btn.className = 'quiz-option';
        btn.setAttribute('role', 'button');
        btn.setAttribute('tabindex', '0');
        btn.innerHTML = `<span class="opt-letter">${String.fromCharCode(65 + i)}</span><span>${opt}</span>`;
        btn.addEventListener('click', () => selectOption(i, btn));
        btn.addEventListener('keydown', e => e.key === 'Enter' && selectOption(i, btn));
        opts.appendChild(btn);
    });

    startQTimer(90);
}

function startQTimer(secs) {
    clearInterval(qTimerInt);
    qTimerSec = secs;
    updateQTimer();
    qTimerInt = setInterval(() => {
        qTimerSec--;
        updateQTimer();
        if (qTimerSec <= 0) { clearInterval(qTimerInt); if (!answered) skipQuestion(); }
    }, 1000);
}

function updateQTimer() {
    const m = Math.floor(qTimerSec / 60).toString().padStart(2, '0');
    const s = (qTimerSec % 60).toString().padStart(2, '0');
    const el = document.getElementById('qTimer');
    if (!el) return;
    el.textContent = `${m}:${s}`;
    el.style.color = qTimerSec <= 20 ? 'var(--danger)' : 'var(--primary-light)';
}

function selectOption(i, btn) {
    if (answered) return;
    answered = true;
    clearInterval(qTimerInt);
    const q = APTITUDE_QUESTIONS[qIdx];
    document.querySelectorAll('.quiz-option').forEach((o, idx) => {
        if (idx === q.ans) o.classList.add('correct');
        else if (idx === i && i !== q.ans) o.classList.add('wrong');
    });
    if (i === q.ans) { correct++; showToast('✅ Correct!', 'success', 1500); }
    else { wrong++; showToast('❌ Wrong! Check explanation below.', 'error', 2000); }
    document.getElementById('explanationDiv').style.display = 'block';
    document.getElementById('explanationText').textContent = q.exp;
    document.getElementById('nextBtn').style.display = 'inline-flex';
    updateScore();
}

function skipQuestion() {
    if (!answered) { skipped++; answered = true; }
    clearInterval(qTimerInt);
    updateScore();
    qIdx++;
    loadQuestion();
}

function nextQuestion() {
    qIdx++;
    loadQuestion();
}

function updateScore() {
    document.getElementById('correctCount').textContent = correct;
    document.getElementById('wrongCount').textContent = wrong;
    document.getElementById('skipCount').textContent = skipped;
    const done = correct + wrong;
    const pct = done > 0 ? Math.round((correct / done) * 100) : 0;
    document.getElementById('accuracyBar').style.width = pct + '%';
    document.getElementById('accuracyPct').textContent = pct + '%';
}

function showQuizComplete() {
    const total = APTITUDE_QUESTIONS.length;
    const pct = Math.round((correct / total) * 100);
    const color = pct >= 70 ? 'var(--accent)' : pct >= 50 ? 'var(--warning)' : 'var(--danger)';
    const grade = pct >= 80 ? '🥇 Excellent' : pct >= 60 ? '🥈 Good' : '📚 Keep Practising';

    const card = document.getElementById('quizCard');
    if (!card) return;
    card.innerHTML = `
    <div style="text-align:center;padding:1.5rem 0;">
      <div style="font-size:4rem;margin-bottom:1rem;">🎉</div>
      <h3 style="font-family:'Outfit',sans-serif;font-size:1.4rem;font-weight:900;color:var(--text-primary);margin-bottom:0.5rem;">Quiz Complete!</h3>
      <div style="font-family:'Outfit',sans-serif;font-size:3rem;font-weight:900;color:${color};margin-bottom:0.5rem;">${pct}%</div>
      <p style="color:var(--text-muted);margin-bottom:1.5rem;">${correct}/${total} correct &middot; ${wrong} wrong &middot; ${skipped} skipped</p>
      <div style="background:var(--bg-surface);border-radius:var(--radius-lg);padding:1rem;margin-bottom:1.5rem;font-size:0.875rem;color:var(--text-secondary);">
        Grade: <strong style="color:${color};">${grade}</strong>
      </div>
      <button class="btn btn-primary" onclick="initQuiz()">🔄 Retake Quiz</button>
    </div>`;

    const ovApt = document.getElementById('ov-apt');
    if (ovApt) ovApt.textContent = pct + '%';
    updateOverall();

    // Save to backend if logged in
    if (typeof AuthAPI !== 'undefined' && AuthAPI.isLoggedIn() && typeof PlacementAPI !== 'undefined') {
        PlacementAPI.saveScore({ test_type: 'aptitude', score_pct: pct, correct, wrong, skipped })
            .catch(() => { /* non-critical */ });
        showToast(`🎯 Score ${pct}% saved to your profile!`, 'success', 2500);
    }
}

function updateOverall() {
    const a = parseInt(document.getElementById('ov-apt')?.textContent) || 0;
    const c = parseInt(document.getElementById('ov-code')?.textContent) || 0;
    const h = parseInt(document.getElementById('ov-hr')?.textContent) || 0;
    const counts = [a, c, h].filter(x => x > 0);
    if (counts.length) {
        const avg = Math.round(counts.reduce((s, v) => s + v, 0) / counts.length);
        const el = document.getElementById('ov-overall');
        if (el) el.textContent = avg + '%';
    }
}

// ══ RENDER PANELS ════════════════════════════════════════
function renderCodingTopics() {
    const grid = document.getElementById('codingTopicsGrid');
    if (!grid) return;
    CODING_TOPICS.forEach(t => {
        const card = document.createElement('div');
        card.className = 'topic-card';
        card.innerHTML = `
      <div style="font-size:2.5rem;margin-bottom:0.75rem;">${t.emoji}</div>
      <h4 style="font-size:0.95rem;font-weight:700;color:var(--text-primary);margin-bottom:0.5rem;">${t.title}</h4>
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span style="font-size:0.78rem;color:var(--text-muted);">${t.count} questions</span>
        <span class="badge" style="background:${t.color}22;color:${t.color};border:1px solid ${t.color}33;font-size:0.68rem;">${t.difficulty}</span>
      </div>
      <button class="btn btn-primary btn-sm" style="width:100%;justify-content:center;margin-top:1rem;"
        onclick="showToast('${t.title} practice starting...','info');setTimeout(()=>showToast('✅ 15 questions ready! Refresh page to reload quiz.','success'),1200)">
        Start Practice →</button>`;
        grid.appendChild(card);
    });
}

function renderHRQuestions() {
    const list = document.getElementById('hrQuestionsList');
    if (!list) return;
    HR_QUESTIONS.forEach((q, i) => {
        const div = document.createElement('div');
        div.style.cssText = 'background:var(--bg-surface);border-radius:var(--radius-lg);overflow:hidden;';
        div.innerHTML = `
      <div style="display:flex;align-items:center;gap:0.875rem;padding:0.875rem 1rem;cursor:pointer;"
           onclick="this.nextElementSibling.classList.toggle('hidden')">
        <span style="width:26px;height:26px;background:var(--grad-primary);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.72rem;font-weight:800;color:white;flex-shrink:0;">${i + 1}</span>
        <span style="font-size:0.875rem;font-weight:600;color:var(--text-primary);flex:1;">${q.q}</span>
        <span style="color:var(--text-muted);">▼</span>
      </div>
      <div class="hidden" style="padding:0.875rem 1rem 1rem;border-top:1px solid var(--bg-glass-border);">
        <div style="font-size:0.78rem;font-weight:700;color:var(--primary-light);margin-bottom:0.375rem;">💡 Tips:</div>
        <p style="font-size:0.82rem;color:var(--text-secondary);line-height:1.7;margin:0;">${q.hint}</p>
      </div>`;
        list.appendChild(div);
    });
}

function renderGDTopics() {
    const grid = document.getElementById('gdTopicsGrid');
    if (!grid) return;
    GD_TOPICS.forEach(t => {
        const card = document.createElement('div');
        card.className = 'topic-card';
        card.innerHTML = `
      <div style="display:flex;align-items:center;gap:0.875rem;margin-bottom:0.875rem;">
        <span style="font-size:1.75rem;">${t.emoji}</span>
        <span class="badge" style="background:${t.color}1a;color:${t.color};border:1px solid ${t.color}33;font-size:0.7rem;">${t.cat}</span>
      </div>
      <p style="font-size:0.9rem;font-weight:700;color:var(--text-primary);line-height:1.4;margin-bottom:0.875rem;">"${t.title}"</p>
      <button class="btn btn-outline btn-sm" style="width:100%;justify-content:center;"
        onclick="showToast('Opening GD prep...','info');setTimeout(()=>showToast('GD point builder: argue both sides clearly, give data points, conclude with balanced view.','success'),1500)">
        Prepare Points →</button>`;
        grid.appendChild(card);
    });
}

function renderCompanies() {
    const grid = document.getElementById('companyGrid');
    if (!grid) return;
    COMPANIES.forEach(c => {
        const card = document.createElement('div');
        card.className = 'topic-card';
        card.style.cssText = 'cursor:pointer;position:relative;overflow:hidden;';
        const diffClass = c.difficulty === 'Hard' ? 'badge-danger' : c.difficulty === 'Medium' ? 'badge-warning' : 'badge-success';
        const diffEmoji = c.difficulty === 'Hard' ? '🔥' : c.difficulty === 'Medium' ? '⚡' : '✅';
        card.innerHTML = `
      <div style="position:absolute;top:0;right:0;width:80px;height:80px;background:radial-gradient(circle at top right,rgba(79,70,229,0.08),transparent);border-radius:0 var(--radius-xl) 0 50%;pointer-events:none;"></div>
      <div style="display:flex;align-items:center;gap:0.875rem;margin-bottom:1rem;">
        <span style="font-size:2.25rem;transition:transform .3s;" class="company-logo-${c.name}">${c.logo}</span>
        <div>
          <div style="font-weight:800;color:var(--text-primary);font-size:1.05rem;">${c.name}</div>
          <span class="badge ${diffClass}" style="margin-top:0.25rem;font-size:0.65rem;">${diffEmoji} ${c.difficulty}</span>
        </div>
      </div>
      <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:0.375rem;display:flex;align-items:center;gap:.4rem;">📋 <span>${c.rounds}</span></div>
      <div style="font-size:0.82rem;color:var(--accent);font-weight:700;margin-bottom:1rem;">💰 ${c.package}</div>
      <a href="company-detail.html?company=${encodeURIComponent(c.name)}"
         class="btn btn-primary btn-sm"
         style="width:100%;justify-content:center;text-decoration:none;"
         onclick="event.stopPropagation();">
        View Prep Guide →
      </a>`;
        // Whole card clickable
        card.addEventListener('click', () => {
            window.location.href = `company-detail.html?company=${encodeURIComponent(c.name)}`;
        });
        // Logo bounce on hover
        card.addEventListener('mouseenter', () => {
            const logo = card.querySelector(`.company-logo-${c.name}`);
            if (logo) logo.style.transform = 'scale(1.2) rotate(-5deg)';
        });
        card.addEventListener('mouseleave', () => {
            const logo = card.querySelector(`.company-logo-${c.name}`);
            if (logo) logo.style.transform = 'scale(1) rotate(0deg)';
        });
        grid.appendChild(card);
    });
}

// ══ TAB SWITCHER ═════════════════════════════════════════
function switchTest(id, btn) {
    document.querySelectorAll('.test-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    ['aptitude', 'coding', 'hr', 'gd', 'company'].forEach(p => {
        const el = document.getElementById('panel-' + p);
        if (el) el.style.display = p === id ? 'block' : 'none';
    });
}

// ══ INIT ═════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
    initQuiz();
    renderCodingTopics();
    renderHRQuestions();
    renderGDTopics();
    renderCompanies();
});
