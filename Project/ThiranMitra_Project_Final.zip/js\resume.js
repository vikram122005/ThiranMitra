/* ============================================
   WorkMitra — resume.js
   AI Resume Analyzer — all logic extracted
   ============================================ */
'use strict';

// ── Drag & Drop ───────────────────────────────
function handleDragOver(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.add('drag-over');
}
function handleDragLeave(e) {
    document.getElementById('dropZone').classList.remove('drag-over');
}
function handleDrop(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
}
function handleFileSelect(input) {
    if (input.files[0]) processFile(input.files[0]);
}

function processFile(file) {
    const allowed = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain'
    ];
    if (!allowed.includes(file.type) && !file.name.match(/\.(pdf|doc|docx|txt)$/i)) {
        showToast('Please upload a PDF, DOC, DOCX, or TXT file.', 'error');
        return;
    }
    if (file.size > 5 * 1024 * 1024) {
        showToast('File size exceeds 5MB limit. Please compress and try again.', 'error');
        return;
    }
    const dz = document.getElementById('dropZone');
    dz.innerHTML = `
    <span class="drop-zone-icon">✅</span>
    <h3 style="color:var(--accent);">File Ready: ${file.name}</h3>
    <p style="font-size:0.8rem;color:var(--text-muted);">${(file.size / 1024).toFixed(1)} KB — Click "Analyze Resume" to continue.</p>`;
    showToast(`📄 ${file.name} uploaded successfully!`, 'success');

    // If text file, auto-populate textarea
    if (file.type === 'text/plain') {
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('resumeText').value = e.target.result;
        };
        reader.readAsText(file);
    }
}

// ── Analyze Flow ─────────────────────────────
function analyzeResume() {
    const text = document.getElementById('resumeText').value.trim();
    const fileInput = document.getElementById('resumeFile');
    if (!text && (!fileInput.files || !fileInput.files[0])) {
        showToast('Please upload a resume file or paste resume text.', 'error');
        return;
    }
    document.getElementById('uploadCard').style.display = 'none';
    document.getElementById('loadingPanel').style.display = 'block';

    const steps = [
        [15, 'Scanning document structure...'],
        [30, 'Running ATS compatibility check...'],
        [50, 'Analyzing keywords and skills...'],
        [70, 'Checking grammar and formatting...'],
        [85, 'Comparing with job market trends...'],
        [95, 'Generating improvement suggestions...'],
        [100, 'Analysis complete!'],
    ];

    let si = 0;
    const interval = setInterval(() => {
        if (si >= steps.length) { clearInterval(interval); showResults(); return; }
        const pb = document.getElementById('analysisProgress');
        const ps = document.getElementById('analysisStep');
        if (pb) pb.style.width = steps[si][0] + '%';
        if (ps) ps.textContent = steps[si][1];
        si++;
    }, 600);
}

// ── Show Results ─────────────────────────────
function showResults() {
    const role = (document.getElementById('targetRole')?.value || '').trim() || 'General';
    document.getElementById('loadingPanel').style.display = 'none';
    const panel = document.getElementById('analysisPanel');
    if (!panel) return;
    panel.classList.add('visible');

    // ATS Score
    const score = Math.floor(Math.random() * 25) + 55;
    const arc = document.getElementById('scoreArc');
    if (arc) arc.style.strokeDashoffset = 408 - (408 * score / 100);
    const os = document.getElementById('overallScore');
    if (os) os.textContent = score;
    const gradeEl = document.getElementById('scoreGrade');
    if (gradeEl) {
        const grade = score >= 85 ? '🥇 Excellent' : score >= 70 ? '🥈 Good' : score >= 55 ? '🥉 Average' : '⚠️ Needs Work';
        gradeEl.innerHTML = `<span class="gradient-text">${grade}</span>`;
    }
    const msgEl = document.getElementById('scoreMsg');
    if (msgEl) msgEl.textContent = score >= 70
        ? 'Your resume is ATS-friendly with some improvements needed.'
        : 'Your resume needs significant improvements for better ATS compatibility.';

    // Metrics
    const metrics = [
        { val: score + '%', lbl: 'ATS Score', color: 'var(--primary-light)' },
        { val: Math.floor(Math.random() * 3) + 1, lbl: 'Grammar Issues', color: 'var(--warning)' },
        { val: Math.floor(Math.random() * 15) + 60 + '%', lbl: 'Skill Match', color: 'var(--accent)' },
        { val: Math.floor(Math.random() * 3) + 3 + '/10', lbl: 'Formatting', color: 'var(--secondary)' },
        { val: Math.floor(Math.random() * 3) + 6 + '/10', lbl: 'Content Quality', color: '#a78bfa' },
        { val: Math.floor(Math.random() * 20) + 70 + '%', lbl: 'Completeness', color: '#34d399' },
    ];
    const mg = document.getElementById('metricsGrid');
    if (mg) {
        mg.innerHTML = '';
        metrics.forEach(m => {
            const div = document.createElement('div');
            div.className = 'analysis-metric';
            div.innerHTML = `<div class="metric-val" style="color:${m.color};">${m.val}</div><div class="metric-lbl">${m.lbl}</div>`;
            mg.appendChild(div);
        });
    }

    // Keywords
    const roleKeywords = {
        'data analyst': { found: ['Python', 'SQL', 'Excel', 'Tableau', 'Problem Solving'], missing: ['Machine Learning', 'Power BI', 'R', 'Statistics', 'Big Data'] },
        'software engineer': { found: ['Python', 'OOP', 'Git', 'Agile', 'Problem Solving'], missing: ['Docker', 'AWS', 'System Design', 'CI/CD', 'Kafka'] },
        'hr manager': { found: ['Communication', 'Leadership', 'Teamwork', 'MS Office'], missing: ['HRIS', 'Recruitment', 'Payroll', 'Compliance', 'HR Analytics'] },
    };
    const lowerRole = role.toLowerCase();
    const kw = roleKeywords[lowerRole] || {
        found: ['Python', 'Problem Solving', 'Teamwork', 'Leadership', 'Communication', 'Agile', 'Git'],
        missing: ['Machine Learning', 'Cloud', 'Docker', 'System Design', 'API Development', 'Data Analysis'],
    };

    const kf = document.getElementById('keywordsFound');
    const km = document.getElementById('keywordsMissing');
    if (kf) { kf.innerHTML = ''; kw.found.forEach(k => { const s = document.createElement('span'); s.className = 'badge keyword-found'; s.textContent = k; kf.appendChild(s); }); }
    if (km) { km.innerHTML = ''; kw.missing.forEach(k => { const s = document.createElement('span'); s.className = 'badge keyword-missing'; s.textContent = '− ' + k; km.appendChild(s); }); }

    // Improvements
    const improvements = [
        { type: 'bad', icon: '❌', msg: 'Add a professional summary section at the top of your resume.' },
        { type: 'bad', icon: '❌', msg: 'Quantify achievements: "Increased sales by 30%" instead of "Improved sales".' },
        { type: 'tip', icon: '💡', msg: `Add missing keywords for ${role} roles: ${kw.missing.slice(0, 3).join(', ')}.` },
        { type: 'good', icon: '✅', msg: 'Good use of action verbs (Developed, Implemented, Managed).' },
        { type: 'bad', icon: '❌', msg: 'Resume longer than 2 pages — trim to 1–2 pages for ATS compatibility.' },
        { type: 'tip', icon: '💡', msg: 'Use a clean single-column layout. Avoid tables and graphics for ATS.' },
        { type: 'good', icon: '✅', msg: 'Contact info is complete (Name, Phone, Email, LinkedIn).' },
        { type: 'tip', icon: '💡', msg: `Add a Skills section with specific ${role} competencies.` },
    ];
    const il = document.getElementById('improvementsList');
    if (il) {
        il.innerHTML = '';
        improvements.forEach(item => {
            const div = document.createElement('div');
            div.className = `improvement-item ${item.type}`;
            div.innerHTML = `<span style="font-size:1.1rem;flex-shrink:0;">${item.icon}</span><p style="font-size:0.875rem;color:var(--text-secondary);line-height:1.6;margin:0;">${item.msg}</p>`;
            il.appendChild(div);
        });
    }

    // Save to backend if logged in
    if (typeof AuthAPI !== 'undefined' && AuthAPI.isLoggedIn()) {
        const filename = document.getElementById('resumeFile')?.files[0]?.name || `resume_${role}.txt`;
        apiFetch('/profile/resumes', {
            method: 'POST',
            body: JSON.stringify({
                filename,
                ats_score: score,
                grammar_score: metrics[1].val === 0 ? 95 : 80,
                keywords_found: JSON.stringify(kw.found),
                improvements: JSON.stringify(improvements.map(i => i.msg)),
            })
        }).then(() => {
            showToast(`✅ ATS Score ${score}/100 saved to your profile!`, 'success', 2500);
        }).catch(() => { /* non-critical */ });
    } else {
        showToast(`📊 ATS Score: ${score}/100 — Login to save your results!`, 'info', 3000);
    }
}

// ── Reset ─────────────────────────────────────
function analyzeAgain() {
    document.getElementById('uploadCard').style.display = 'block';
    const panel = document.getElementById('analysisPanel');
    if (panel) panel.classList.remove('visible');
    ['metricsGrid', 'keywordsFound', 'keywordsMissing', 'improvementsList'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = '';
    });
    const ta = document.getElementById('resumeText');
    if (ta) ta.value = '';
    const dz = document.getElementById('dropZone');
    if (dz) dz.innerHTML = `
    <span class="drop-zone-icon">📄</span>
    <h3 style="color:var(--text-primary);margin-bottom:0.75rem;">Drag &amp; drop your resume here</h3>
    <p>or <strong onclick="event.stopPropagation();document.getElementById('resumeFile').click()">click to browse</strong></p>
    <p style="margin-top:0.5rem;font-size:0.8rem;">Supports PDF, DOC, DOCX, TXT — Max 5MB</p>
    <input type="file" id="resumeFile" accept=".pdf,.doc,.docx,.txt" style="display:none;" onchange="handleFileSelect(this)"/>`;
}

// ── Download Improved Resume Template ─────────
function downloadImprovedResume() {
    const role = (document.getElementById('targetRole')?.value || '').trim() || 'Your Target Role';
    const content = `IMPROVED RESUME — WorkMitra AI
==============================
Generated: ${new Date().toLocaleDateString('en-IN')}
Target Role: ${role}

[YOUR FULL NAME]
Email: yourname@email.com | Phone: +91-XXXXXXXXXX
LinkedIn: linkedin.com/in/yourprofile | GitHub: github.com/yourusername
Location: City, State, India

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROFESSIONAL SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Results-driven ${role} with [X] years of experience in [Domain/Industry].
Proven track record of [Key Achievement with metric, e.g., "reducing costs by 20%"].
Passionate about [Area of Expertise] with strong problem-solving and communication skills.
Seeking to leverage skills at [Target Company] to [Goal].

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TECHNICAL SKILLS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Programming:  Python, JavaScript, SQL
Frameworks:   [Relevant frameworks for ${role}]
Tools:        Git, Docker, AWS/GCP, Jira, Figma
Soft Skills:  Leadership, Communication, Teamwork, Problem Solving, Agile/Scrum

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WORK EXPERIENCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[JOB TITLE] | [COMPANY NAME] | [City] | [Month Year – Month Year]
• Increased [metric] by 30% through [specific action / technology used]
• Developed [system/feature] serving [N] users, resulting in [measurable outcome]
• Led a team of [N] to deliver [project] on time and [X]% under budget
• Automated [process] using [tool], saving [N] hours per week

[PREVIOUS JOB TITLE] | [PREVIOUS COMPANY] | [Date Range]
• [Achievement with quantified result]
• [Achievement with quantified result]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EDUCATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[DEGREE] in [Branch] | [INSTITUTION] | [City] | [Year Passed]
CGPA: [Score] / 10   |   Relevant Coursework: [Course 1], [Course 2]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
KEY PROJECTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Project Name] | [Tech Stack: Python, Flask, React] | GitHub: link
• Built [what it does] for [target users] — achieved [metric/result]
• [Technical highlight]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CERTIFICATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• [Certification Name] — [Issuer, e.g., Google/Coursera/NPTEL] (Year)
• [Certification Name] — [Issuer] (Year)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ACHIEVEMENTS & EXTRA-CURRICULARS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• [Hackathon/Competition win or rank]
• [Leadership role — club, committee]
• [Volunteer work with impact]

────────────────────────────────
This improved resume template was generated by WorkMitra AI.
ATS Tips: Use keywords from the job description. Keep to 1–2 pages.
Avoid: Tables, text boxes, headers/footers, images, graphs.
────────────────────────────────`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `WorkMitra_Improved_Resume_${role.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('📥 Improved resume template downloaded!', 'success');
}
